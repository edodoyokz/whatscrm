const appVersion = "2.3";
const addON = ["AI_BOT"];

module.exports = { appVersion, addON };
